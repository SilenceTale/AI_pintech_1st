package org.koreait.etc;

import lombok.Data;

@Data
public class Greet {
    private String name;
}
